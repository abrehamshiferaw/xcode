# 🐾 The Velvet Leash: Daily Paws Report Generator

A lightweight, full-stack internal web application built for **The Velvet Leash Boutique & Boarding**. This tool allows daycare staff to quickly generate and share "Daily Paws Reports" with pet parents via unique, mobile-responsive web links.

## 🌟 Features

* **Staff Input Form:** A fast, streamlined interface for staff to log a pet's energy level, meal consumption, best friends, and daily notes.
* **Instant Report Generation:** Generates a unique, read-only URL (e.g., `/report/unique-id`) immediately upon form submission.
* **Parent View:** A clean, mobile-first, boutique-styled summary page for pet owners to view their dog’s specific report on the go.
* **Local Storage:** Uses SQLite for lightweight, reliable data persistence.

## 🛠 Tech Stack

* **Language:** Swift 5.5
* **Framework:** Vapor 4
* **Database & ORM:** SQLite & Fluent
* **Templating:** Leaf
* **Styling:** Custom CSS (Mobile-first, boutique aesthetic)
* **IDE:** Xcode

## 🚀 Getting Started

Follow these instructions to get a copy of the project up and running on your local machine.

### Prerequisites

* A Mac running macOS.
* **Xcode** installed (If on macOS Big Sur 11, use Xcode 13.2.1).
* Swift Package Manager (built into Xcode).

### Installation & Setup

1. **Clone the repository:**
   ```bash
   git clone [https://github.com/your-username/VelvetLeash.git](https://github.com/your-username/VelvetLeash.git)
   cd VelvetLeash
